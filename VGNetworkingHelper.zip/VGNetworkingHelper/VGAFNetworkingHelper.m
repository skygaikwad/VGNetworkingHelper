//
//  VGAFNetworkingHelper.m
//
//  Created by Vaibhav Gaikwad on 15 Dec 2016.
//  Copyright (c) 2016 WhiteBirdTechnology. All rights reserved.
//

#import "VGAFNetworkingHelper.h"
#import "AppDelegate.h"
#import <AFNetworking/AFNetworking.h>
@implementation VGAFNetworkingHelper

-(id)init{
    
    if (self = [super init])
    {
        self.showLoadingView = YES;
    }
    return self;
}


+ (VGAFNetworkingHelper *)sharedInstance {
    static id sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[self alloc] init];
    });
    
    return sharedInstance;
}


- (void)performRequestWithPath:(NSString *)path withAuth:(BOOL)needsAuth withRequestJSONSerialized:(BOOL)reqJSONSerialized withCompletionHandler:(VGAFNetworkRequestCompletionHandler) handler {
    
    [self performRequestWithPath:path withAuth:needsAuth forMethod:@"GET" withRequestJSONSerialized:reqJSONSerialized withParams:nil withCompletionHandler:handler];
}


- (void)performRequestWithPath:(NSString *)path withAuth:(BOOL)needsAuth forMethod:(NSString *)method withRequestJSONSerialized:(BOOL)reqJSONSerialized withParams:(id)params withCompletionHandler:(VGAFNetworkRequestCompletionHandler) handler
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    if(reqJSONSerialized == NO){
        manager.requestSerializer = [AFHTTPRequestSerializer serializer];
        [manager.requestSerializer setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
   
    } else {
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        [manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        [manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Accept"];
    }
    
    if (needsAuth){
        [manager.requestSerializer clearAuthorizationHeader];
    }
    
    manager.responseSerializer =[AFJSONResponseSerializer serializer];
    manager.responseSerializer.acceptableContentTypes = [manager.responseSerializer.acceptableContentTypes setByAddingObject:@"text/html"];
    manager.responseSerializer.acceptableContentTypes = [manager.responseSerializer.acceptableContentTypes setByAddingObject:@"text/plain"];
    
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    
    
    //Depending on the method type we proceed to the corresponding execution
    if([method isEqualToString:@"POST"]) {
        [manager POST:path parameters:params progress:Nil success:^(NSURLSessionTask *operation, id responseObject) {

            if(handler) {
                handler([self prepareResponseObject:YES withData:responseObject andError:nil]);
            }
            if (self.showLoadingView)
                return ;
            
        }failure:^(NSURLSessionTask *operation, NSError *error) {
            
            if(handler) {
                handler([self prepareResponseObject:NO withData:nil andError:error]);
            }
            
            if (error.code == -1009) {
//                [self LoadNoInternetView:YES];
            }
        }
         ];
        
    } else if ([method isEqualToString:@"GET"]) {
        [manager GET:path parameters:nil progress:nil success:^(NSURLSessionTask *task, id responseObject) {
            if (handler) {
                handler([self prepareResponseObject:YES withData:responseObject andError:nil]);
            }
            
        } failure:^(NSURLSessionTask *operation, NSError *error)  {
            if(handler) {
                handler([self prepareResponseObject:NO withData:nil andError:error]);
            }
        }];
        
    } else if ([method isEqualToString:@"PUT"]) {
        [manager POST:path parameters:params progress:Nil success:^(NSURLSessionTask *operation, id responseObject) {
            if (handler) {
                handler([self prepareResponseObject:YES withData:responseObject andError:nil]);
            }
            
        } failure:^(NSURLSessionTask *operation, NSError *error)  {
            if(handler) {
                handler([self prepareResponseObject:NO withData:nil andError:error]);
            }
            
        }];
        
    }
}


#pragma mark - Helper functions
- (VGAFNetworkingResponse *)prepareResponseObject:(BOOL) success
                                    withData:(id)response
                                    andError: (NSError *)error{
    
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    
    VGAFNetworkingResponse *responseDetails = [[VGAFNetworkingResponse alloc] init];
    responseDetails.isSuccessful = success;
    responseDetails.data = response;
    responseDetails.error = error;
    return responseDetails;
}


-(void)LoadNoInternetView:(BOOL)Show {
    
    if ([[[UIApplication sharedApplication] keyWindow].subviews containsObject: self.noInternetView] == Show) {
        return;
        
    }
    
    if (Show) {
        
        if (!self.noInternetView) {
            
            self.isInternetViewVisible = YES;
            UINib *nib = [UINib nibWithNibName:@"CLNoInternetView" bundle:nil];
            self.noInternetView = [[nib instantiateWithOwner:self options:nil] objectAtIndex:0];
            
            self.noInternetView.frame = [[UIApplication sharedApplication] keyWindow].frame;
            
            self.noInternetView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.8];
        }
        
        BOOL addinternetView = YES;
        
        AppDelegate *myAppDelegate = (AppDelegate*)[[UIApplication sharedApplication]delegate];
        
        for(UIView *view in myAppDelegate.window.subviews)
        {
            if([view isKindOfClass:[CLNoInternetView class]])
            {
                addinternetView = NO;
            }
        }
        
        if (addinternetView) {
            [[[UIApplication sharedApplication] keyWindow] addSubview: self.noInternetView];
        }
    } else {
        self.isInternetViewVisible = NO;
        [self.noInternetView removeFromSuperview];
    }
}


- (void)dealloc
{
    [[AFNetworkReachabilityManager sharedManager] stopMonitoring];
}


@end

