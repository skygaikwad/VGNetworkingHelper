//
//  VGAFNetworkingResponse.h
//
//  Created by Vaibhav Gaikwad on 15 Dec 2016.
//  Copyright (c) 2016 WhiteBirdTechnology. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VGAFNetworkingResponse : NSObject
@property (nonatomic, assign) BOOL isSuccessful;
@property (nonatomic, retain) NSError * error;
@property (nonatomic, retain) id data;

@end
