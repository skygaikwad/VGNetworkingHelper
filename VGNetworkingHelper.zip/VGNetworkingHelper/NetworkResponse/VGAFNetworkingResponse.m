//
//  VGAFNetworkingResponse.m
//
//  Created by Vaibhav Gaikwad on 15 Dec 2016.
//  Copyright (c) 2016 WhiteBirdTechnology. All rights reserved.
//

#import "VGAFNetworkingResponse.h"

@implementation VGAFNetworkingResponse
@synthesize isSuccessful;
@synthesize data;
@synthesize error;
@end
