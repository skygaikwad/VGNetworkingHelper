//
//  CLNoInternetView.h
//
//  Created by Vaibhav Gaikwad on 15 Dec 2016.
//  Copyright (c) 2016 WhiteBirdTechnology. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLNoInternetView : UIView

@property (strong, nonatomic) IBOutlet UIView *containerView;

@property (strong, nonatomic) IBOutlet UIButton *tryAgainButton;

@end
