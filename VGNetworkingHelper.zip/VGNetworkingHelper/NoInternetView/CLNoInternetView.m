//
//  CLNoInternetView.m
//
//  Created by Vaibhav Gaikwad on 15 Dec 2016.
//  Copyright (c) 2016 WhiteBirdTechnology. All rights reserved.
//

#import "CLNoInternetView.h"
#import <AFNetworking/AFNetworking.h>

@implementation CLNoInternetView

-(void)awakeFromNib{
    
    [[AFNetworkReachabilityManager sharedManager] startMonitoring];
    
}

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    
    self.containerView.layer.cornerRadius = 5.0f;
    self.tryAgainButton.layer.cornerRadius = 5.0f;
    
    [self.containerView setClipsToBounds:YES];
    [self.tryAgainButton setClipsToBounds:YES];
}

-(IBAction)tryAgain:(id)sender {
    if ([self connected]) {
        [self removeFromSuperview];
        
        [[AFNetworkReachabilityManager sharedManager] stopMonitoring];
    }
}


- (BOOL)connected {
    return [AFNetworkReachabilityManager sharedManager].reachable;
}
@end
